# aWavegent Full Example Pack

This package combines:
- the aWavegent marketing site layer
- the modular business page engine
- shared styles
- reusable section files
- two complete JSON-driven examples

## Main files
- `/index.html` → launcher / overview page
- `/sales/wavegent-homepage.html` → marketing homepage
- `/examples/restaurant/index.html` → full restaurant example
- `/examples/charter/index.html` → full charter example

## How to create another example
1. Duplicate `/examples/restaurant` or `/examples/charter`
2. Rename the folder
3. Keep `index.html`
4. Replace `data.json`
5. Edit the `sections` array inside `data.json` to turn modules on/off

## Available section modules
- profile
- social-icons
- specials-banner
- links
- booking-charter
- booking-reservation
- menu-text
- menu-images
- reviews-verified
- gallery-grid
- hours

## Notes
- `template.html` was converted into the example `index.html` files.
- Relative paths were fixed so the examples load correctly from `/examples/...`
- The examples are data-driven. The JSON is the business record.